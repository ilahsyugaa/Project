CREATE TABLE articles (
ArticleID INT PRIMARY KEY,
  Title VARCHAR(255),
  Content VARCHAR(255),
  PublicationDate DATE,
  AuthorID VARCHAR(30),
  TagID INT,
  ViewsCount INT,
  LikesCount INT,
  WordCount INT,
  Featured BOOLEAN,
  check (Featured in (0, 1)),
  SourceAttribution VARCHAR(255),
  CategoryID INT,
  FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID),
  FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID),
  FOREIGN KEY (TagID) REFERENCES Tags(TagID));
  
  describe articles;
  
INSERT INTO articles (ArticleID, Title, Content, PublicationDate, AuthorID, TagID, ViewsCount, LikesCount, WordCount, Featured, SourceAttribution,CategoryID)
VALUES
(1001, 'Penjelasan Teknologi Blockchain', 'Demystifying the Distributed Ledger', '2023-11-18', 'A031', 300, 1200, 250, 900, true, 'Malay Mail',501),
(1002, 'Pengenalan kepada Sains Quantum', 'Artikel ini membincangkan konsep-konsep asas dalam sains quantum', '2023-12-03', 'A032', 301, 800, 150, 700, false, 'The Star Malaysia',502),
(1003, 'Transformasi Sistem Pilihan Raya', 'Cabaran dan Harapan', '2023-01-07', 'A033', 302, 1000, 180, 1100, true, 'New Straits Times',503),
(1004, 'Muzik Klasik dalam Dunia Kontemporari', 'Kemerduan yang Abadi', '2023-02-12', 'A034', 303, 600, 120, 800, false, 'The Edge Malaysia',504),
(1005, 'Cabaran dan Kemenangan: Kisah Inspirasi di Balik Sukan Ekstrem', 'Menyelami dunia sukan ekstrem dan menceritakan kisah atlet yang menghadapi cabaran besar', '2024-03-20', 'A035', 304, 1500, 280, 5466, true, 'Bernama',505),
(1006, 'Inovasi Perniagaan dalam Era Digital', 'Membentuk Masa Depan Keusahawanan', '2023-04-25', 'A036', 305, 700, 120, 879, false, 'Astro Awani',506),
(1007, 'Manfaat Bersenam: Zumba sebagai Pilihan', 'Kelebihan dan kegembiraan bersenam melalui Zumba', '2023-05-30', 'A037', 306, 900, 190, 980, true, 'Malay Mail',507),
(1008, 'Keindahan Keindahan Pantai Malaysia', 'Penerokaan kecantikan pantai-pantai Malaysia', '2023-03-10', 'A038', 307, 1156, 280, 453, false, 'The Star Malaysia',508),
(1009, 'Evolusi Fesyen', 'Menelusuri Perkembangan Gaya dari Masa ke Masa', '2024-04-05', 'A039', 308, 1346, 290, 546, true, 'New Straits Times',509),
(1010, 'Perjalanan Rasa', 'Menjelajah Kelezatan Kuliner dari Seluruh Dunia', '2023-05-20', 'A040', 309, 1796, 290, 578, false, 'The Edge Malaysia',510),
(1011, 'Ekspresi Diri melalui Lukisan Abstrak', 'Penjelajahan Keseniannya', '2023-06-15', 'A041', 310, 1790, 200, 707, false, 'Bernama',511),
(1012, 'Transformasi Pendidikan Digital', 'Menyusuri Jalan Ke Arah Pembelajaran Era Baru', '2023-07-08', 'A042', 311, 1905, 540, 475, false, 'Astro Awani',512),
(1013, 'Inovasi dalam Pembangunan Bandar', 'Perubahan landskap bandar melalui inovasi', '2023-08-01', 'A043', 312, 1536, 260, 315, true, 'Malay Mail',513),
(1014, 'Perjalanan Musik Pop', 'Evolusi Gaya dan Pengaruhnya dalam Budaya Populer', '2023-09-12', 'A044', 313, 1863, 780, 135, true, 'The Star Malaysia',514),
(1015, 'Evokasi Emosi Melalui Layar Perak', 'Kekuatan dan Pengaruh Seni Filem', '2023-10-25', 'A045', 314, 120, 235, 468, false, 'New Straits Times',515),
(1016, 'Buku-Buku Bestseller yang Mendedahkan Realiti Sosial', 'Membaca di Antara Baris-Baris', '2023-11-18', 'A046', 315, 140, 224, 128, true, 'The Edge Malaysia',516),
(1017, 'Panduan Pemula untuk Pengurusan Kewangan', 'Membina Asas Kewangan yang Tahan Lama', '2023-12-03', 'A047', 316, 580, 890, 351, false, 'Bernama',517),
(1018, 'Menggali Kecantikan Keragaman Budaya', 'Warisan dan Tradisi di Seluruh Dunia', '2024-01-07', 'A048', 317, 265, 900, 412, true, 'Astro Awani',518),
(1019, 'Kelebihan Sistem Penjana Kuasa', 'Perkembangan dalam penjana kuasa alternatif', '2024-02-12', 'A049', 318, 1236, 850, 233, false, 'Malay Mail',519),
(1020, 'Permainan Video dan Kesenian Interaktif', 'Penerokaan Dunia Kreatif dalam Industri Permainan', '2024-03-20', 'A050', 319, 458, 900, 253, false, 'The Star Malaysia',520),
(1021, 'Transformasi Kehidupan Melalui Senaman', 'Cara Memulai Perjalanan Kecergasan Anda', '2024-04-25', 'A051', 320, 1655, 550, 335, false, 'New Straits Times',521),
(1022, 'Peristiwa Bersejarah yang Membentuk Dunia', 'Penelusuran Rentetan Perubahan', '2024-05-30', 'A031', 321, 253, 670, 321, true, 'The Edge Malaysia',522),
(1023, 'Keindahan Alam yang Menakjubkan', 'Memahami dan Menerapkan Kelestarian', '2024-06-15', 'A032', 322, 860, 980, 286, false, 'Bernama',523),
(1024, 'Seni dan Teknik Fotografi', 'Panduan untuk Pemula dalam Mencipta Karya Indah', '2024-07-20', 'A033', 323, 960, 340, 786, true, 'Astro Awani',524),
(1025, 'Keberagaman Agama', ' Memahami dan Menghormati Perbezaan Keyakinan', '2024-08-15', 'A034', 324, 961, 670, 846, true, 'Malay Mail',525),
(1026, 'Tren Teknologi 2024', 'Masa Depan Inovasi yang Membentuk Dunia Kita', '2024-09-30', 'A045', 325, 1860, 350, 315, false, 'The Star Malaysia',526),
(1027, 'Ekonomi Berkelanjutan', 'Membina Masa Depan yang Lebih Hijau dan Adil', '2023-10-25', 'A051', 326, 862, 270, 684, true, 'New Straits Times',527),
(1028, 'Eksplorasi Ruang Angkasa', 'Masa Depan Penjelajahan Antariksa dan Kedudukan Manusia di Alam Semesta', '2024-11-12', 'A047', 327, 781, 340, 795, false, 'The Edge Malaysia',528),
(1029, 'Pengaruh Media Sosial dalam Perubahan Budaya dan Komunikasi', 'Tinjauan Terkini', '2024-10-15', 'A048', 328, 912, 560, 362, true, 'Bernama',529),
(1030, 'Perubahan Paradigma dalam Dunia Pemasaran', 'Kehebatan Pemasaran Digital dan Dampaknya terhadap Bisnis', '2023-06-18', 'A050', 329, 321, 890, 481, false, 'Astro Awani',530);

select* from articles;