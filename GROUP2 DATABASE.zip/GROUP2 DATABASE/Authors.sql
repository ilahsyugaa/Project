create table Authors(
AuthorID VARCHAR (30) NOT NULL PRIMARY KEY,
AuthorName VARCHAR (30),
PenName VARCHAR (30),
AuthorEmail VARCHAR (40),
PreviousWorks VARCHAR (50) 
);

describe Authors;

-- Authors for Country category
INSERT INTO Authors (AuthorID, AuthorName, PenName, AuthorEmail, PreviousWorks) VALUES
('A031', 'Daniel Tan', 'D. Tan', 'daniel.tan@example.com', 'National Gazette, Country Insights'),
('A032', 'Jessica Lim', 'J. Lim', 'jessica.lim@example.com', 'Country Life, Rural Chronicles'),
('A033', 'Mohammed Ali', 'M. Ali', 'mohammed.ali@example.com', 'Heritage Times, Cultural Wonders'),
('A034', 'Sophie Chang', 'S. Chang', 'sophie.chang@example.com', 'Arts Weekly, Entertainment Digest'),
('A035', 'Alexandre Dubois', 'A. Dubois', 'alexandre.dubois@example.com', 'Cinema Review, Music Magic'),
('A036', 'Emily Chen', 'E. Chen', 'emily.chen@example.com', 'Showbiz Insider, Celeb Chronicles'),
('A037', 'Rachel Williams', 'R. Williams', 'rachel.williams@example.com', 'Global Insights, World Affairs'),
('A038', 'Maximilian Mueller', 'M. Mueller', 'maximilian.mueller@example.com', 'Worldwide Times, International Pulse'),
('A039', 'Elena Petrov', 'E. Petrov', 'elena.petrov@example.com', 'Worldviews, Cross-Cultural Exchange'),
('A040', 'James Johnson', 'J. Johnson', 'james.johnson@example.com', 'Business Herald, Financial Focus'),
('A041', 'Sophia Wong', 'S. Wong', 'sophia.wong@example.com', 'Economic Outlook, Market Trends'),
('A042', 'Michael Tan', 'M. Tan', 'michael.tan@example.com', 'Corporate Insights, Entrepreneurial Spirit'),
('A043', 'Adam Lee', 'A. Lee', 'adam.lee@example.com', 'Sports Spectator, Athletic Achievements'),
('A044', 'Emma Baker', 'E. Baker', 'emma.baker@example.com', 'Sporting Times, Fitness Focus'),
('A045', 'Ryan Chen', 'R. Chen', 'ryan.chen@example.com', 'Game On, Sporting Insights'),
('A046', 'Oliver Davis', 'O. Davis', 'oliver.davis@example.com', 'Political Observer, Governance Matters'),
('A047', 'Isabelle Nguyen', 'I. Nguyen', 'isabelle.nguyen@example.com', 'Policy Perspective, Government Watch'),
('A048', 'Jack Wilson', 'J. Wilson', 'jack.wilson@example.com', 'Political Pulse, Public Affairs'),
('A049', 'Mohammad Rahman', 'M. Rahman', 'mohammad.rahman@example.com', 'Malaysian Times, Local Insights'),
('A050', 'Siti Abdullah', 'S. Abdullah', 'siti.abdullah@example.com', 'Malaysia News Today, Local Affairs'),
('A051', 'Lee Wei', 'L. Wei', 'lee.wei@example.com', 'Malaysian Chronicle, Current Affairs') ;

select* from Authors;