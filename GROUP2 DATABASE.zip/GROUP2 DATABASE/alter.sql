update articles
set SourceAttribution = 'Bernama'
where ArticleID = '1001';


select* from articles;

-- Update foreign key references to NULL or another valid value
UPDATE articles SET AuthorID = NULL 
WHERE AuthorID IN (SELECT AuthorID FROM Authors 
WHERE PreviousWorks = 'National Gazette, Country Insights');

-- Then delete the record in the parent table
DELETE FROM Authors WHERE PreviousWorks = 'National Gazette, Country Insights';

select* from Authors;

SELECT Title, MAX(ViewsCount) AS MaxViews
FROM articles
GROUP BY Title
ORDER BY MaxViews ASC
LIMIT 0, 1000;


SELECT * FROM articles 
WHERE Featured = 1 AND CategoryID = 501;

SELECT Authors.AuthorName, COUNT(articles.ArticleID) AS ArticleCount, SUM(articles.WordCount) AS TotalWordCount
FROM Authors
LEFT JOIN articles ON Authors.AuthorID = articles.AuthorID
GROUP BY Authors.AuthorName;


SELECT Title, WordCount
FROM Articles
WHERE WordCount > 1000;
