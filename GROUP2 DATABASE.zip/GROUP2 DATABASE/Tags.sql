create table Tags (
TagID INT (10) NOT NULL PRIMARY KEY,
TagName VARCHAR (30)
);

describe Tags;

INSERT INTO Tags (TagID, TagName) VALUES
(300, 'Technology'),
(301, 'Science'),
(302, 'Politics'),
(303, 'Entertainment'),
(304, 'Sports'),
(305, 'Business'),
(306, 'Health'),
(307, 'Travel'),
(308, 'Fashion'),
(309, 'Food'),
(310, 'Art'),
(311, 'Education'),
(312, 'Environment'),
(313, 'Music'),
(314, 'Movies'),
(315, 'Books'),
(316, 'Finance'),
(317, 'Culture'),
(318, 'Automobile'),
(319, 'Gaming'),
(320, 'Fitness'),
(321, 'History'),
(322, 'Nature'),
(323, 'Photography'),
(324, 'Religion'),
(325, 'Technology Trends'),
(326, 'Economy'),
(327, 'Space'),
(328, 'Social Media'),
(329, 'Digital Marketing');

select* from Tags;