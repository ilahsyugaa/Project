CREATE TABLE Categories (
    CategoryID INT NOT NULL PRIMARY KEY,
    CategoryName VARCHAR(50)
);

describe Categories;

INSERT INTO Categories (CategoryID, CategoryName) VALUES
(501, 'Technology'),
(502, 'Science'),
(503, 'Politics'),
(504, 'Entertainment'),
(505, 'Sports'),
(506, 'Business'),
(507, 'Health'),
(508, 'Travel'),
(509, 'Fashion'),
(510, 'Food'),
(511, 'Art'),
(512, 'Education'),
(513, 'Environment'),
(514, 'Music'),
(515, 'Movies'),
(516, 'Books'),
(517, 'Finance'),
(518, 'Culture'),
(519, 'Automobile'),
(520, 'Gaming'),
(521, 'Fitness'),
(522, 'History'),
(523, 'Nature'),
(524, 'Photography'),
(525, 'Religion'),
(526, 'Technology Trends'),
(527, 'Economy'),
(528, 'Space'),
(529, 'Social Media'),
(530, 'Digital Marketing');

select* from Categories;
